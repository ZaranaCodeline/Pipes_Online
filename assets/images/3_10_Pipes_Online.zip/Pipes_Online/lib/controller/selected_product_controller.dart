import 'package:get/get.dart';
import 'package:url_launcher/url_launcher.dart';

class SelectedProductController extends GetxController{

  openWhatApp() async {
    var whatsappUrl = "whatsapp://send?phone=+91 9340104438&text=Hey";
    if (await canLaunch(whatsappUrl)) {

      launch(whatsappUrl);
    } else {
      // Get.showSnackbar();
    }
  }
  @override
  void onReady() {
    // TODO: implement onReady
    super.onReady();
  }

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
  }
}