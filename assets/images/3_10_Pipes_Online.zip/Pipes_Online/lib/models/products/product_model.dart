class Product {
  String title;
  String desc;
  String price;
  String imgUrl;

  Product(
      {required this.price,
      required this.desc,
      required this.title,
      required this.imgUrl});


}
