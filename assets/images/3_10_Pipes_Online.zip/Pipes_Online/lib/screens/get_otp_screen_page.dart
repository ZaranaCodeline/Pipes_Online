import 'package:flutter/material.dart';

class GetOTPScreenPage extends StatelessWidget {
  const GetOTPScreenPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
